﻿using System;

/*
Ho Choi - 2139224
*/

namespace examen_final_choi
{
    class Program
    {
        static void Main(string[] args)
        {
            Cliente cliente = new Cliente();
            cliente.solicitarDatos();
            mostrarMenu(cliente);
        }

        public static void mostrarMenu(Cliente cliente)
        {
            while (true)
            {
                Console.WriteLine("Elige una opcion dentro del menu:");
                Console.WriteLine("1. Mostrar datos del cliente");
                Console.WriteLine("2. Mostrar clases disponibles");
                Console.WriteLine("3. Mostrar sedes disponibles y sus clases");
                Console.WriteLine("4. Salir");

                string opcion = Console.ReadLine();
                switch (opcion)
                {
                    case "1":
                        cliente.mostrarDatos();
                        Console.ReadKey();
                        break;
                    case "2":
                        Lecciones.mostrarClasesDisponibles();
                        Console.ReadKey();
                        break;
                    case "3":
                        Lecciones.mostrarSedesYClases();
                        Console.ReadKey();
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Opcion no valida. Intente de nuevo.");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }

    class Cliente
    {
        public string NombreCliente { get; set; }
        public int NumeroTelefonico { get; set; }
        public string SedeCliente { get; set; }

        public Cliente() { }

        public void solicitarDatos()
        {
            bool esValido;
            Console.WriteLine("DATOS DEL CLIENTE");

            // Se solicita nombre del cliente
            do
            {
                Console.WriteLine("Ingrese su primer nombre y su primer apellido:");
                NombreCliente = Console.ReadLine();
                esValido = VerificarNombre(NombreCliente);
                if (!esValido)
                {
                    Console.WriteLine("Nombre no valido. El nombre debe tener entre 3 y 25 caracteres.");
                }
            } while (!esValido); // Verifica nombre del cliente
            Console.WriteLine("");

            // Ingreso de telefono
            do
            {
                Console.WriteLine("Ingrese su numero telefonico (8 digitos):");
                string inputNumero = Console.ReadLine();
                try
                {
                    NumeroTelefonico = int.Parse(inputNumero);
                    if (inputNumero.Length != 8)
                    {
                        Console.WriteLine("Numero de telefono debe contener 8 digitos.");
                        esValido = false;
                    }
                    else
                    {
                        esValido = true;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ingrese un valor numerico valido para el numero telefonico.");
                    esValido = false;
                }
            } while (!esValido);
            Console.WriteLine("");
        }

        public void mostrarDatos()
        {
            Console.WriteLine("Datos del Cliente:");
            Console.WriteLine("Nombre: " + NombreCliente);
            Console.WriteLine("Numero Telefonico: " + NumeroTelefonico);
            Console.WriteLine("Sede: " + SedeCliente);
            Console.WriteLine("");
        }

        private static bool VerificarNombre(string nombreCliente)
        {
            return !string.IsNullOrWhiteSpace(nombreCliente) && nombreCliente.Length >= 3 && nombreCliente.Length <= 25;
        }
    }

    static class Lecciones
    {
        public static string[] clasesDisponibles = new string[] { "Pilates", "Aerobics", "Spinning" };
        public static string[] sedesDisponibles = new string[] { "Roosevelt", "Villa Nueva" };
        public static string[] leccionesRoosevelt = new string[] { "Pilates", "Spinning" };
        public static string[] leccionesVillaNueva = new string[] { "Aerobics", "Pilates" };

        public static void mostrarClasesDisponibles()
        {
            Console.WriteLine("Clases disponibles:");
            foreach (var clase in clasesDisponibles)
            {
                Console.WriteLine(clase);
            }
            Console.WriteLine("");
        }

        public static void mostrarSedesYClases()
        {
            Console.WriteLine("Sedes:");
            Console.WriteLine("Roosevelt:");
            foreach (var clase in leccionesRoosevelt)
            {
                Console.WriteLine(" -" + clase);
            }
            Console.WriteLine("Villa Nueva:");
            foreach (var clase in leccionesVillaNueva)
            {
                Console.WriteLine($" -" + clase);
            }
            Console.WriteLine("");
        }
    }
}
