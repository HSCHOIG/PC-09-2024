﻿namespace semana_12
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
        }
 
        static void menu()
        {
            Console.WriteLine("Semana 12");
            Console.WriteLine(" a) Multiplicación");
            Console.WriteLine(" b) suma");
            Console.WriteLine(" c) Resta ");
 
            char opcion = Console.ReadLine().ToLower()[0];
            switch (opcion)
            {
                case 'a':
                    Console.WriteLine("Ingrese un número para multiplicar");
                    int aMult = Convert.ToInt32(Console.ReadLine());
 
                    Console.WriteLine("Ingrese un número para multiplicar");
                    int bMult = Convert.ToInt32(Console.ReadLine());
 
                    Console.WriteLine("El resultado es :" + Multiplicacion(aMult, bMult));
                    Console.ReadKey();
 
                    break;
                    
                    case 'b':
                    Console.WriteLine("Ingrese un número para sumar");
                    int aSum = Convert.ToInt32(Console.ReadLine());
 
                    Console.WriteLine("Ingrese un número para sumar");
                    int bSum = Convert.ToInt32(Console.ReadLine());
 
                    Console.WriteLine("El resultado es :" + Suma(aSum, bSum));
                    Console.ReadKey();
 
                    break;

                    case 'c':
                    Console.WriteLine("Ingrese un número para restar");
                    int aRes = Convert.ToInt32(Console.ReadLine());
 
                    Console.WriteLine("Ingrese un número para restar");
                    int bRes = Convert.ToInt32(Console.ReadLine());
 
                    Console.WriteLine("El resultado es :" + Resta(aRes, bRes));
                    Console.ReadKey();
 
                    break;

                default:
                    Console.WriteLine("La opción seleccionada no es válida.");
                    break;
            }
        }
 
        //envio de parámetros
        public static int Multiplicacion(int a, int b)
        {
            int resultado = 0;
            resultado = a * b;
            return resultado;
        }

        public static int Suma(int a, int b){
            int total = 0;
            total = a + b;
            return total;
        }

        public static int Resta(int a, int b){
            int diferencia = 0;
            diferencia = a - b;
            return diferencia;
        }
 
    }
}