﻿using System;

/*
Ho Choi - 2139224
*/
namespace RestauranteDoniaPelos
{
    class Program
    {
        public static string Nombre;
        public static string direccion;
        public string comidaDespachada;
        public string sede;
        public string tamales;
        public static int opcion;

        static void Main(string[] args)
        {
            bool menu = true;
            while(menu){
            Cliente.crearCliente();
            Pedido.crearPedido();
            }
        }

        public class Cliente
        {
            public string nombreCliente;
            public int NumeroTelefono;
            public string Direccion;

            public static Cliente crearCliente()
            {
                Console.WriteLine("Ingrese nombre del cliente");
                string nombre = Console.ReadLine();
                Console.WriteLine("Ingrese Direccion del Domicilio");
                string direccion = Console.ReadLine();
                Console.WriteLine("Ingrese numero telefonico");
                int numeroTelefono = Convert.ToInt32(Console.ReadLine());

                return new Cliente
                {
                    nombreCliente = nombre,
                    Direccion = direccion,
                    NumeroTelefono = numeroTelefono
                };
            }
        }

        public class Pedido
        {
            string formaPago;
            static int totalPedido;
            static int totalPedido2;

            public static void crearPedido()
            {
                DateTime dateTime = DateTime.Now;
                Console.WriteLine("Cuantos tamales va a llevar?");
                totalPedido = Convert.ToInt32(Console.ReadLine());
                totalPedido2 = totalPedido * 6;
                Console.WriteLine("El total a pagar es " + totalPedido2 + " y la cantidad de tamales es " + totalPedido);
            }
        }
    }
}