﻿using System;

public class Choi
{
    // Propiedades
    int edad;
    string nombre;
    int anioDeNacimiento;

    // Constructor
    public Choi(int edad, string nombre, int anioDeNacimiento)
    {
        this.nombre = nombre;
        this.edad = edad;
        this.anioDeNacimiento = anioDeNacimiento;
    }

    // Metodo para mostrar los valores
    public void Mostrar()
    {
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Edad: " + edad);
        Console.WriteLine("Año de nacimiento: " + anioDeNacimiento);
    }

    // Metodo para ingresar variables
    public void IngresarVariables()
    {
        Console.WriteLine("Escriba su año de nacimiento:");
        anioDeNacimiento = int.Parse(Console.ReadLine());
        Console.WriteLine("Escriba su edad:");
        edad = int.Parse(Console.ReadLine());
        Console.WriteLine("Escriba su nombre:");
        nombre = Console.ReadLine();
    }

    // Metodo para mostrar el menu
    public void Menu()
    {
        while (true)
        {
            Console.WriteLine("Elija una opción:");
            Console.WriteLine("1) Ingresar valores");
            Console.WriteLine("2) Mostrar valores");
            Console.WriteLine("3) Salir del programa");

            int opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("Ingresar valores:");
                    IngresarVariables();
                    break;
                case 2:
                    Console.WriteLine("Los valores ingresados son:");
                    Mostrar();
                    break;
                case 3:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no válida");
                    break;
            }
        }
    }

    // Metodo Main para iniciar el programa
    public static void Main()
    {
        Choi choi = new Choi(0, "", 0);
        choi.Menu();
    }
}
