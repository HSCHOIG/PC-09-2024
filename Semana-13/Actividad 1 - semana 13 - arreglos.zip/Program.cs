﻿using System;

namespace Arreglos
{
    class ArregloUnidimensional
    {
        static void Main(string[] args)
        {

            string[] numeros = PedirNumeros();

            Console.WriteLine("Su nombre es, su apellido, su edady su telefono es:");
            MostrarNumeros(numeros);
        }

        static string[] PedirNumeros()
        {
            string[] numeros = new string[4];
            Console.WriteLine("Ingrese datos: Nombre, apellido, edad y numero de telefono");
            Console.WriteLine("se solicita que los ingrese en ese orden para su mejor experiencia");
            for (int n = 0; n < 4; n++)
            {
                Console.Write($"Dato {n + 1}: ");
                numeros[n] = Console.ReadLine();
            }

            return numeros;
        }
        static void MostrarNumeros(string[] numeros)
        {
            foreach (var numero in numeros)
            {
                Console.WriteLine(numero);
            }

        }
    }
}
