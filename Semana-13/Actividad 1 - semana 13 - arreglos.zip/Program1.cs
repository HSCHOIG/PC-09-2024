﻿using System;

//Roberth Melendez - 1200824
//Luis Andrade - 1135724
//Ho Choi - 2139224

namespace Arreglos
{
    class ArregloUnidimensional
    {

        static void Main(string[] args)
        {

            int[] numeros = PedirNumeros();

            Console.WriteLine("Los numeros ingresados son:");
            MostrarNumeros(numeros);
            SumarNumeros(numeros);
            PromedioNumeros(numeros);
        }

        static int[] PedirNumeros()
        {
            int[] numeros = new int[8];
            Console.WriteLine("Ingrese 8 numeros");
            for (int n = 0; n < 8; n++)
            {
                Console.Write($"Numero {n + 1}: ");
                numeros[n] = Convert.ToInt32(Console.ReadLine());
            }

            return numeros;
        }
        static void MostrarNumeros(int[] numeros)
        {
            foreach (var numero in numeros)
            {
                Console.WriteLine(numero);
            }

        }
                static void SumarNumeros(int[] numeros)
        {
            decimal total = 0m;
            foreach (var numero in numeros)
            {
                total += numero;
            }
            Console.WriteLine("La suma es:");
            Console.WriteLine(total);
        }
        static void PromedioNumeros(int[] numeros)
        {
            decimal promed = 0m;
            decimal total = 0m;
            foreach (var numero in numeros)
            {
                total += numero;
            }

            promed = total/numeros.Length;
            Console.WriteLine("La prom es:");
            Console.WriteLine(promed);
        }
    }
}
