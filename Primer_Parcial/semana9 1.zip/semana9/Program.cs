﻿

namespace Semana9{
  class Program
  {
    static void Main (string [] args)
    {


      Console.WriteLine("Cual es su nombre?");
      string nombre = Console.ReadLine();
      Console.WriteLine("Cuantos anios tiene usted?");
      string numero = Console.ReadLine();

      int num = int.TryParse(input, out int num);

        switch (num)
        {
          case < 6:
          {
            Console.WriteLine("askdfbd");

            Console.WriteLine(nombre + num  + ", Usted se encuentra en la primera infancia ha vivido " + (num * 12) + " meses, " + (num * 365");

            break;
          }

          default:
          break;
        }

      }
    }
  }
    
}
