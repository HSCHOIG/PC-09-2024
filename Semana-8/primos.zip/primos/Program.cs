﻿using System;

class Fase1
{
    static void Main(string[] args)
    {
        int numero = 0;
        int number = 0;

        Console.WriteLine("Ingrese un número que no sea 1, 2 o 3:");
        string input = Console.ReadLine();

        bool esNumeroValido = int.TryParse(input, out numero);

        if (esNumeroValido)
        {
            if (numero == 2)
            {
                Console.WriteLine(numero + " es un número primo.");
            }
            else if (numero % 2 == 0)
            {
                if (numero % 3 == 0)
                {
                    Console.WriteLine("No es un numero primo");
                }
            }
            else
            {
                Console.WriteLine("Es un numero primo");
            }
        }
        else
        {
            Console.WriteLine("Entrada no válida. Por favor, ingrese un número válido.");
        }
    }
}
