﻿using System;

class PrimerProyecto
{
    static int tarray = 12;
    static int[] arr = new int[tarray];
    static int numenu;
    static int menuop;
    static int promedio;

    static void Main(string[] args)
    {
        string textoimp = "";
        Solicitar();
        menu();
        int numeros;
    }

    static void Solicitar()
    {
        for (int i = 0; i < tarray; i++)
        {
            Console.WriteLine($"Numero {i + 1}: ");
            arr[i] = int.Parse(Console.ReadLine());
        }
    }

    static void menu()
    {
        while (true)
        {
            Console.WriteLine("MENU");
            Console.WriteLine("1. SUMA DE LOS NUMEROS");
            Console.WriteLine("2. PROMEDIO");
            Console.WriteLine("3. DE MENOR A MAYOR");
            Console.WriteLine("4. DE MAYOR A MENOR");
            Console.WriteLine("5. CAMBIAR LA CANTIDAD DE NUMEROS INGRESADOS");
            int menuop = int.Parse(Console.ReadLine());
            int suma = 0;

            switch (menuop)
            {
                case 1:

                    for (int i = 0; i < tarray; i++)
                    {
                        suma = arr[i] + suma;
                    }
                    Console.WriteLine("La suma total es: " + suma);
                    Console.ReadKey();
                    suma = 0;
                    break;
                case 2:

                    for (int i = 0; i < tarray; i++)
                    {
                        suma = arr[i] + suma;
                    }

                    promedio = suma / tarray;

                    Console.WriteLine("El promedio total es: " + promedio);
                    Console.ReadKey();

                    break;
                case 3:
                    Console.WriteLine("Los numeros ordenados de menor a mayor son: ");

                    Array.Sort(arr);
                    foreach (int menormayou in arr)
                    {
                        Console.WriteLine(menormayou);
                    }
                    Console.ReadKey();

                    break;
                case 4:
                    Array.Sort(arr);
                    Array.Reverse(arr);
                    foreach (int menormayou in arr)
                    {
                        Console.WriteLine(menormayou);
                    }
                    Console.ReadKey();
                    break;
                case 5:
                    Console.WriteLine("Desea cambiar el Tamanio del array?");

                    Array.Resize(ref arr, 14);
                    Console.WriteLine($"Resizing 6 ... count: {arr.Length}");

                    arr[13] = 01;
                    arr[12] = 02;
                    foreach (var arra in arr)
                    {
                        Console.WriteLine(arr);
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
